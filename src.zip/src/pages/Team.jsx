import { useState, useMemo, useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import TeamHeader from '../components/team/TeamHeader'
import TeamSummary from '../components/team/TeamSummary'
import TeamToolbar from '../components/team/TeamToolbar'
import TeamTable from '../components/team/TeamTable'
import AddTeamMemberDrawer from '../components/team/AddTeamMemberDrawer'
import TeamMemberDetailsDrawer from '../components/team/TeamMemberDetailsDrawer'
import EditTeamMemberDrawer from '../components/team/EditTeamMemberDrawer'
import DeleteTeamMemberModal from '../components/team/DeleteTeamMemberModal'
import { MOCK_TEAM } from '../data/team'

const TEAM_PER_PAGE = 8

function Team() {
  const [teamMembers, setTeamMembers] = useState(MOCK_TEAM)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [roleFilter, setRoleFilter] = useState('All Roles')
  const [currentPage, setCurrentPage] = useState(1)

  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState(null)
  const [editingMember, setEditingMember] = useState(null)
  const [deletingMember, setDeletingMember] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Compute unique roles currently present in team members
  const roleOptions = useMemo(() => {
    const roles = new Set()
    teamMembers.forEach((m) => {
      if (m.role) roles.add(m.role)
    })
    return ['All Roles', ...Array.from(roles).sort()]
  }, [teamMembers])

  // Real-time client-side filtering: search + status + role
  const filteredMembers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()

    return teamMembers.filter((member) => {
      // 1. Search matches: name, email, phone, role, department
      const matchesSearch =
        !q ||
        member.name.toLowerCase().includes(q) ||
        member.email.toLowerCase().includes(q) ||
        (member.phone && member.phone.toLowerCase().includes(q)) ||
        member.role.toLowerCase().includes(q) ||
        member.department.toLowerCase().includes(q)

      // 2. Status match
      const matchesStatus =
        statusFilter === 'All Status' || member.status === statusFilter

      // 3. Role match
      const matchesRole =
        roleFilter === 'All Roles' || member.role === roleFilter

      return matchesSearch && matchesStatus && matchesRole
    })
  }, [teamMembers, searchQuery, statusFilter, roleFilter])

  // Pagination calculation
  const totalFilteredCount = filteredMembers.length
  const totalPages = Math.max(1, Math.ceil(totalFilteredCount / TEAM_PER_PAGE))
  const activePage = Math.min(currentPage, totalPages)

  // Page clamping: if deleting or filtering items shrinks the list, move to last valid page
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  // Paginated slice for current page
  const paginatedMembers = useMemo(() => {
    const startIndex = (activePage - 1) * TEAM_PER_PAGE
    return filteredMembers.slice(startIndex, startIndex + TEAM_PER_PAGE)
  }, [filteredMembers, activePage])

  // Filter change handlers resetting page to 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handleRoleChange = (role) => {
    setRoleFilter(role)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  // Toast notification helper
  const showToast = (message) => {
    setToastMessage(message)
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  // CRUD Handlers
  const handleOpenAddDrawer = () => {
    setIsAddDrawerOpen(true)
  }

  const handleCloseAddDrawer = () => {
    setIsAddDrawerOpen(false)
  }

  const handleSaveMember = (newMember) => {
    setTeamMembers((prev) => [newMember, ...prev])
    setCurrentPage(1)
    showToast('Team member added successfully.')
  }

  const handleViewMember = (member) => {
    setSelectedMember(member)
  }

  const handleCloseDetails = () => {
    setSelectedMember(null)
  }

  const handleEditMember = (member) => {
    setSelectedMember(null) // Seamless transition: close details drawer if open
    setEditingMember(member)
  }

  const handleCloseEditDrawer = () => {
    setEditingMember(null)
  }

  const handleUpdateMember = (updatedMember) => {
    setTeamMembers((prev) =>
      prev.map((member) =>
        member.id === updatedMember.id ? updatedMember : member
      )
    )
    setEditingMember(null)
    showToast('Team member updated successfully.')
  }

  const handlePromptDelete = (member) => {
    setDeletingMember(member)
  }

  const handleCloseDeleteModal = () => {
    setDeletingMember(null)
  }

  const handleConfirmDelete = (memberId) => {
    setTeamMembers((prev) => prev.filter((m) => m.id !== memberId))

    if (selectedMember?.id === memberId) setSelectedMember(null)
    if (editingMember?.id === memberId) setEditingMember(null)

    setDeletingMember(null)
    showToast('Team member deleted successfully.')
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Add Team Member Action */}
      <TeamHeader onAddMember={handleOpenAddDrawer} />

      {/* 2. Compact Dynamic Metric Summary Row (Total, Active, On Leave, Inactive) */}
      <TeamSummary teamMembers={teamMembers} />

      {/* 3. Main Workspace Card (Toolbar + Table + Pagination) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <TeamToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          roleFilter={roleFilter}
          onRoleChange={handleRoleChange}
          roleOptions={roleOptions}
          totalCount={totalFilteredCount}
        />

        <TeamTable
          teamMembers={paginatedMembers}
          totalLifetimeCount={teamMembers.length}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={totalFilteredCount}
          itemsPerPage={TEAM_PER_PAGE}
          onPageChange={handlePageChange}
          onViewMember={handleViewMember}
          onEditMember={handleEditMember}
          onDeleteMember={handlePromptDelete}
          onAddMember={handleOpenAddDrawer}
        />
      </div>

      {/* 4. Slide-over Add Team Member Drawer */}
      <AddTeamMemberDrawer
        isOpen={isAddDrawerOpen}
        onClose={handleCloseAddDrawer}
        onSaveMember={handleSaveMember}
      />

      {/* 5. Slide-over Team Member Details Drawer */}
      <TeamMemberDetailsDrawer
        member={selectedMember}
        isOpen={Boolean(selectedMember)}
        onClose={handleCloseDetails}
        onEdit={handleEditMember}
      />

      {/* 6. Slide-over Edit Team Member Drawer */}
      <EditTeamMemberDrawer
        member={editingMember}
        isOpen={Boolean(editingMember)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdateMember}
      />

      {/* 7. Delete Team Member Confirmation Modal */}
      <DeleteTeamMemberModal
        member={deletingMember}
        isOpen={Boolean(deletingMember)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Team
