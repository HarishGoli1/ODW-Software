import DashboardHeader from '../components/DashboardHeader'
import KpiGrid from '../components/KpiGrid'
import BusinessOverview from '../components/BusinessOverview'
import BusinessPulse from '../components/BusinessPulse'
import QuickActions from '../components/QuickActions'

function Dashboard() {
  return (
    <div className="space-y-6">
      {/* 1. Header Shell */}
      <DashboardHeader />

      {/* 2. Key Metrics Grid */}
      <KpiGrid />

      {/* 3. Business Overview */}
      <BusinessOverview />

      {/* 4. Business Pulse */}
      <BusinessPulse />

      {/* 5. Quick Actions */}
      <QuickActions />
    </div>
  )
}

export default Dashboard
