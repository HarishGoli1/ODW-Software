import { useState, useMemo } from 'react'
import { CheckCircle2 } from 'lucide-react'
import LeadsHeader from '../components/leads/LeadsHeader'
import LeadSummary from '../components/leads/LeadSummary'
import LeadsToolbar from '../components/leads/LeadsToolbar'
import LeadsTable from '../components/leads/LeadsTable'
import AddLeadDrawer from '../components/leads/AddLeadDrawer'
import LeadDetailsDrawer from '../components/leads/LeadDetailsDrawer'
import EditLeadDrawer from '../components/leads/EditLeadDrawer'
import DeleteLeadModal from '../components/leads/DeleteLeadModal'
import { LEADS_SUMMARY, MOCK_LEADS } from '../data/leads'

const ITEMS_PER_PAGE = 8

function Leads() {
  const [leads, setLeads] = useState(MOCK_LEADS)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [sourceFilter, setSourceFilter] = useState('All Sources')
  const [currentPage, setCurrentPage] = useState(1)
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [selectedLead, setSelectedLead] = useState(null)
  const [editingLead, setEditingLead] = useState(null)
  const [deletingLead, setDeletingLead] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Filter leads based on active search, status, and source criteria
  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      // 1. Search Query Match (Name, Company, Email, Service)
      const matchesSearch =
        searchQuery.trim() === '' ||
        lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.service.toLowerCase().includes(searchQuery.toLowerCase())

      // 2. Status Match
      const matchesStatus =
        statusFilter === 'All Status' || lead.status === statusFilter

      // 3. Source Match
      const matchesSource =
        sourceFilter === 'All Sources' || lead.source === sourceFilter

      return matchesSearch && matchesStatus && matchesSource
    })
  }, [leads, searchQuery, statusFilter, sourceFilter])

  // Total pages based on filtered results
  const totalPages = Math.max(1, Math.ceil(filteredLeads.length / ITEMS_PER_PAGE))

  // Ensure currentPage remains valid if items change
  const activePage = Math.min(currentPage, totalPages)

  // Paginated slice for current page
  const paginatedLeads = useMemo(() => {
    const startIndex = (activePage - 1) * ITEMS_PER_PAGE
    return filteredLeads.slice(startIndex, startIndex + ITEMS_PER_PAGE)
  }, [filteredLeads, activePage])

  // Handlers for search/filter changes with automatic page reset to 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handleSourceChange = (source) => {
    setSourceFilter(source)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  const handleOpenDrawer = () => {
    setIsDrawerOpen(true)
  }

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false)
  }

  const handleViewLead = (lead) => {
    setSelectedLead(lead)
  }

  const handleCloseDetailsDrawer = () => {
    setSelectedLead(null)
  }

  const handleEditLead = (lead) => {
    setSelectedLead(null) // Close details drawer if open
    setEditingLead(lead)
  }

  const handleCloseEditDrawer = () => {
    setEditingLead(null)
  }

  const handlePromptDelete = (lead) => {
    setDeletingLead(lead)
  }

  const handleCloseDeleteModal = () => {
    setDeletingLead(null)
  }

  const handleConfirmDelete = (leadId) => {
    // If the lead currently open in View/Edit drawer is deleted, close them
    if (selectedLead?.id === leadId) setSelectedLead(null)
    if (editingLead?.id === leadId) setEditingLead(null)

    // Filter out the deleted lead from state
    setLeads((prev) => prev.filter((lead) => lead.id !== leadId))
    setDeletingLead(null)

    // Trigger subtle success notification
    setToastMessage('Lead deleted successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handleSaveLead = (newLead) => {
    // Insert new lead safely at the top of local state
    setLeads((prev) => [newLead, ...prev])
    setCurrentPage(1)

    // Trigger subtle success notification
    setToastMessage('Lead added successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handleUpdateLead = (updatedLead) => {
    // Replace the updated lead inside state
    setLeads((prev) =>
      prev.map((lead) => (lead.id === updatedLead.id ? updatedLead : lead))
    )

    // Trigger success notification
    setToastMessage('Lead updated successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Add Lead Button */}
      <LeadsHeader onAddLead={handleOpenDrawer} />

      {/* 2. Compact Metric Summary Row (Total, New, Qualified, Converted) */}
      <LeadSummary summary={LEADS_SUMMARY} />

      {/* 3. Main Workspace Card (Toolbar + Table + Pagination) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <LeadsToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          sourceFilter={sourceFilter}
          onSourceChange={handleSourceChange}
          totalCount={filteredLeads.length}
        />

        <LeadsTable
          leads={paginatedLeads}
          totalLifetimeCount={LEADS_SUMMARY.total}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={filteredLeads.length}
          itemsPerPage={ITEMS_PER_PAGE}
          onPageChange={handlePageChange}
          onSelectLead={handleViewLead}
          onEditLead={handleEditLead}
          onDeleteLead={handlePromptDelete}
        />
      </div>

      {/* 4. Slide-over Add Lead Drawer */}
      <AddLeadDrawer
        isOpen={isDrawerOpen}
        onClose={handleCloseDrawer}
        onSaveLead={handleSaveLead}
      />

      {/* 5. Slide-over Lead Details Drawer */}
      <LeadDetailsDrawer
        lead={selectedLead}
        isOpen={Boolean(selectedLead)}
        onClose={handleCloseDetailsDrawer}
        onEdit={handleEditLead}
      />

      {/* 6. Slide-over Edit Lead Drawer */}
      <EditLeadDrawer
        lead={editingLead}
        isOpen={Boolean(editingLead)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdateLead}
      />

      {/* 7. Centered Delete Confirmation Modal */}
      <DeleteLeadModal
        lead={deletingLead}
        isOpen={Boolean(deletingLead)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Leads
