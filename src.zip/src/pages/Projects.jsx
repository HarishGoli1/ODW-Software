import { useState, useMemo, useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import ProjectsHeader from '../components/projects/ProjectsHeader'
import ProjectSummary from '../components/projects/ProjectSummary'
import ProjectsToolbar from '../components/projects/ProjectsToolbar'
import ProjectsTable from '../components/projects/ProjectsTable'
import AddProjectDrawer from '../components/projects/AddProjectDrawer'
import ProjectDetailsDrawer from '../components/projects/ProjectDetailsDrawer'
import EditProjectDrawer from '../components/projects/EditProjectDrawer'
import DeleteProjectModal from '../components/projects/DeleteProjectModal'
import { PROJECTS_SUMMARY, MOCK_PROJECTS } from '../data/projects'

const ITEMS_PER_PAGE = 8

function Projects() {
  const [projects, setProjects] = useState(MOCK_PROJECTS)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [priorityFilter, setPriorityFilter] = useState('All Priorities')
  const [clientFilter, setClientFilter] = useState('All Clients')
  const [currentPage, setCurrentPage] = useState(1)
  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false)
  const [selectedProject, setSelectedProject] = useState(null)
  const [editingProject, setEditingProject] = useState(null)
  const [deletingProject, setDeletingProject] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Real-time multi-criteria filtering
  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      // 1. Search Query: projectName, clientName, company, service, assignedTo
      const matchesSearch =
        searchQuery.trim() === '' ||
        project.projectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.service.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.assignedTo.toLowerCase().includes(searchQuery.toLowerCase())

      // 2. Status Match
      const matchesStatus =
        statusFilter === 'All Status' || project.projectStatus === statusFilter

      // 3. Priority Match
      const matchesPriority =
        priorityFilter === 'All Priorities' || project.priority === priorityFilter

      // 4. Client Match
      const matchesClient =
        clientFilter === 'All Clients' ||
        project.company === clientFilter ||
        project.clientName === clientFilter

      return matchesSearch && matchesStatus && matchesPriority && matchesClient
    })
  }, [projects, searchQuery, statusFilter, priorityFilter, clientFilter])

  // Pagination calculation
  const totalFilteredCount = filteredProjects.length
  const totalPages = Math.max(1, Math.ceil(totalFilteredCount / ITEMS_PER_PAGE))
  const activePage = Math.min(currentPage, totalPages)

  // Page clamping: prevent invalid pages if items shrink
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  // Paginated slice for current page
  const paginatedProjects = useMemo(() => {
    const startIndex = (activePage - 1) * ITEMS_PER_PAGE
    return filteredProjects.slice(startIndex, startIndex + ITEMS_PER_PAGE)
  }, [filteredProjects, activePage])

  // Filter change handlers with automatic page reset to 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handlePriorityChange = (priority) => {
    setPriorityFilter(priority)
    setCurrentPage(1)
  }

  const handleClientChange = (client) => {
    setClientFilter(client)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  const handleOpenAddDrawer = () => {
    setIsAddDrawerOpen(true)
  }

  const handleCloseAddDrawer = () => {
    setIsAddDrawerOpen(false)
  }

  const handleSaveProject = (newProject) => {
    // Prepend newly created project to state and reset to page 1
    setProjects((prev) => [newProject, ...prev])
    setCurrentPage(1)

    // Success notification
    setToastMessage('Project added successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handleViewProject = (project) => {
    setSelectedProject(project)
  }

  const handleCloseProjectDetails = () => {
    setSelectedProject(null)
  }

  const handleEditProject = (project) => {
    setSelectedProject(null) // Seamless transition: close details drawer if open
    setEditingProject(project)
  }

  const handleCloseEditDrawer = () => {
    setEditingProject(null)
  }

  const handleUpdateProject = (updatedProject) => {
    // Immutable update preserving all fields
    setProjects((prev) =>
      prev.map((project) =>
        project.id === updatedProject.id ? updatedProject : project
      )
    )
    setEditingProject(null)
    setToastMessage('Project updated successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handlePromptDelete = (project) => {
    setDeletingProject(project)
  }

  const handleCloseDeleteModal = () => {
    setDeletingProject(null)
  }

  const handleConfirmDelete = (projectId) => {
    // Immutable filter deletion
    setProjects((prev) => prev.filter((project) => project.id !== projectId))

    // Drawer safety: close if currently open in View or Edit drawer
    if (selectedProject?.id === projectId) setSelectedProject(null)
    if (editingProject?.id === projectId) setEditingProject(null)

    setDeletingProject(null)
    setToastMessage('Project deleted successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Add Project Action */}
      <ProjectsHeader onAddProject={handleOpenAddDrawer} />

      {/* 2. Compact Metric Summary Row (Total, In Progress, In Review, Completed) */}
      <ProjectSummary summary={PROJECTS_SUMMARY} />

      {/* 3. Main Workspace Card (Toolbar + Table + Preview Count) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <ProjectsToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          priorityFilter={priorityFilter}
          onPriorityChange={handlePriorityChange}
          clientFilter={clientFilter}
          onClientChange={handleClientChange}
          totalCount={totalFilteredCount}
        />

        <ProjectsTable
          projects={paginatedProjects}
          totalLifetimeCount={PROJECTS_SUMMARY.total}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={totalFilteredCount}
          itemsPerPage={ITEMS_PER_PAGE}
          onPageChange={handlePageChange}
          onViewProject={handleViewProject}
          onSelectProject={handleViewProject}
          onEditProject={handleEditProject}
          onDeleteProject={handlePromptDelete}
        />
      </div>

      {/* 4. Slide-over Add Project Drawer */}
      <AddProjectDrawer
        isOpen={isAddDrawerOpen}
        onClose={handleCloseAddDrawer}
        onSaveProject={handleSaveProject}
      />

      {/* 5. Slide-over Project Details Drawer */}
      <ProjectDetailsDrawer
        project={selectedProject}
        open={Boolean(selectedProject)}
        onClose={handleCloseProjectDetails}
        onEdit={handleEditProject}
      />

      {/* 6. Slide-over Edit Project Drawer */}
      <EditProjectDrawer
        project={editingProject}
        isOpen={Boolean(editingProject)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdateProject}
      />

      {/* 7. Delete Project Confirmation Modal */}
      <DeleteProjectModal
        project={deletingProject}
        isOpen={Boolean(deletingProject)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Projects
