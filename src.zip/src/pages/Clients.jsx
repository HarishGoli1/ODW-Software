import { useState, useMemo, useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import ClientsHeader from '../components/clients/ClientsHeader'
import ClientSummary from '../components/clients/ClientSummary'
import ClientsToolbar from '../components/clients/ClientsToolbar'
import ClientsTable from '../components/clients/ClientsTable'
import AddClientDrawer from '../components/clients/AddClientDrawer'
import ClientDetailsDrawer from '../components/clients/ClientDetailsDrawer'
import EditClientDrawer from '../components/clients/EditClientDrawer'
import DeleteClientModal from '../components/clients/DeleteClientModal'
import { CLIENTS_SUMMARY, MOCK_CLIENTS } from '../data/clients'

const ITEMS_PER_PAGE = 8

function Clients() {
  const [clients, setClients] = useState(MOCK_CLIENTS)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [serviceFilter, setServiceFilter] = useState('All Services')
  const [currentPage, setCurrentPage] = useState(1)
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [selectedClient, setSelectedClient] = useState(null)
  const [editingClient, setEditingClient] = useState(null)
  const [deletingClient, setDeletingClient] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Real-time multi-criteria filtering
  const filteredClients = useMemo(() => {
    return clients.filter((client) => {
      // 1. Search Query: client name, company, email, service
      const matchesSearch =
        searchQuery.trim() === '' ||
        client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        client.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        client.service.toLowerCase().includes(searchQuery.toLowerCase())

      // 2. Status Match
      const matchesStatus =
        statusFilter === 'All Status' || client.status === statusFilter

      // 3. Service Match
      const matchesService =
        serviceFilter === 'All Services' || client.service === serviceFilter

      return matchesSearch && matchesStatus && matchesService
    })
  }, [clients, searchQuery, statusFilter, serviceFilter])

  // Total pages based on filtered results
  const totalPages = Math.max(1, Math.ceil(filteredClients.length / ITEMS_PER_PAGE))

  // Protect against invalid pages
  const activePage = Math.min(currentPage, totalPages)

  // Automatically keep currentPage in sync if items shrink
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  // Paginated slice for current page
  const paginatedClients = useMemo(() => {
    const startIndex = (activePage - 1) * ITEMS_PER_PAGE
    return filteredClients.slice(startIndex, startIndex + ITEMS_PER_PAGE)
  }, [filteredClients, activePage])

  // Filter change handlers with automatic page reset to 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handleServiceChange = (service) => {
    setServiceFilter(service)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  const handleOpenDrawer = () => {
    setIsDrawerOpen(true)
  }

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false)
  }

  const handleSaveClient = (newClient) => {
    // Prepend newly added client safely to local state and reset to page 1
    setClients((prev) => [newClient, ...prev])
    setCurrentPage(1)

    // Trigger subtle success notification
    setToastMessage('Client added successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handleSelectClient = (client) => {
    setSelectedClient(client)
  }

  const handleCloseDetailsDrawer = () => {
    setSelectedClient(null)
  }

  const handleEditClient = (client) => {
    setSelectedClient(null) // Seamless transition: close details drawer if open
    setEditingClient(client)
  }

  const handleCloseEditDrawer = () => {
    setEditingClient(null)
  }

  const handleUpdateClient = (updatedClient) => {
    // Replace the updated client in state, preserving projects count
    setClients((prev) =>
      prev.map((c) => (c.id === updatedClient.id ? updatedClient : c))
    )

    // Trigger success notification
    setToastMessage('Client updated successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  const handlePromptDelete = (client) => {
    setDeletingClient(client)
  }

  const handleCloseDeleteModal = () => {
    setDeletingClient(null)
  }

  const handleConfirmDelete = (clientId) => {
    // Delete client safely from state
    setClients((prev) => prev.filter((client) => client.id !== clientId))

    // Drawer safety: close view or edit drawers if this client was currently open
    if (selectedClient && selectedClient.id === clientId) {
      setSelectedClient(null)
    }
    if (editingClient && editingClient.id === clientId) {
      setEditingClient(null)
    }

    setDeletingClient(null)

    // Trigger success notification
    setToastMessage('Client deleted successfully.')
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Add Client Button */}
      <ClientsHeader onAddClient={handleOpenDrawer} />

      {/* 2. Compact Metric Summary Row (Total, Active, Projects, Payments) */}
      <ClientSummary summary={CLIENTS_SUMMARY} />

      {/* 3. Main Workspace Card (Toolbar + Table + Pagination) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <ClientsToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          serviceFilter={serviceFilter}
          onServiceChange={handleServiceChange}
          totalCount={filteredClients.length}
        />

        <ClientsTable
          clients={paginatedClients}
          totalLifetimeCount={CLIENTS_SUMMARY.total}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={filteredClients.length}
          itemsPerPage={ITEMS_PER_PAGE}
          onPageChange={handlePageChange}
          onSelectClient={handleSelectClient}
          onEditClient={handleEditClient}
          onDeleteClient={handlePromptDelete}
        />
      </div>

      {/* 4. Slide-over Add Client Drawer */}
      <AddClientDrawer
        isOpen={isDrawerOpen}
        onClose={handleCloseDrawer}
        onSaveClient={handleSaveClient}
      />

      {/* 5. Slide-over Client Details Drawer */}
      <ClientDetailsDrawer
        client={selectedClient}
        isOpen={Boolean(selectedClient)}
        onClose={handleCloseDetailsDrawer}
        onEdit={handleEditClient}
      />

      {/* 6. Slide-over Edit Client Drawer */}
      <EditClientDrawer
        client={editingClient}
        isOpen={Boolean(editingClient)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdateClient}
      />

      {/* 7. Delete Client Confirmation Modal */}
      <DeleteClientModal
        client={deletingClient}
        isOpen={Boolean(deletingClient)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Clients
