import { useState, useMemo, useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import ProposalsHeader from '../components/proposals/ProposalsHeader'
import ProposalSummary from '../components/proposals/ProposalSummary'
import ProposalsToolbar from '../components/proposals/ProposalsToolbar'
import ProposalsTable from '../components/proposals/ProposalsTable'
import AddProposalDrawer from '../components/proposals/AddProposalDrawer'
import ProposalDetailsDrawer from '../components/proposals/ProposalDetailsDrawer'
import EditProposalDrawer from '../components/proposals/EditProposalDrawer'
import DeleteProposalModal from '../components/proposals/DeleteProposalModal'
import { MOCK_PROPOSALS } from '../data/proposals'

const PROPOSALS_PER_PAGE = 8

function Proposals() {
  const [proposals, setProposals] = useState(MOCK_PROPOSALS)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [serviceFilter, setServiceFilter] = useState('All Services')
  const [currentPage, setCurrentPage] = useState(1)

  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false)
  const [selectedProposal, setSelectedProposal] = useState(null)
  const [editingProposal, setEditingProposal] = useState(null)
  const [deletingProposal, setDeletingProposal] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Compute unique services currently present in proposals
  const serviceOptions = useMemo(() => {
    const services = new Set()
    proposals.forEach((p) => {
      if (p.service) services.add(p.service)
    })
    return ['All Services', ...Array.from(services).sort()]
  }, [proposals])

  // Real-time client-side filtering: search + status + service
  const filteredProposals = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()

    return proposals.filter((proposal) => {
      // 1. Search matches: proposalNumber, clientName, company, title, service
      const matchesSearch =
        !q ||
        proposal.proposalNumber.toLowerCase().includes(q) ||
        proposal.clientName.toLowerCase().includes(q) ||
        proposal.company.toLowerCase().includes(q) ||
        proposal.title.toLowerCase().includes(q) ||
        proposal.service.toLowerCase().includes(q)

      // 2. Status match
      const matchesStatus =
        statusFilter === 'All Status' || proposal.status === statusFilter

      // 3. Service match
      const matchesService =
        serviceFilter === 'All Services' || proposal.service === serviceFilter

      return matchesSearch && matchesStatus && matchesService
    })
  }, [proposals, searchQuery, statusFilter, serviceFilter])

  // Pagination calculation
  const totalFilteredCount = filteredProposals.length
  const totalPages = Math.max(1, Math.ceil(totalFilteredCount / PROPOSALS_PER_PAGE))
  const activePage = Math.min(currentPage, totalPages)

  // Page clamping: if deleting or filtering items shrinks the list, move to last valid page
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  // Paginated slice for current page
  const paginatedProposals = useMemo(() => {
    const startIndex = (activePage - 1) * PROPOSALS_PER_PAGE
    return filteredProposals.slice(startIndex, startIndex + PROPOSALS_PER_PAGE)
  }, [filteredProposals, activePage])

  // Filter change handlers resetting to page 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handleServiceChange = (service) => {
    setServiceFilter(service)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  // Toast helper
  const showToast = (message) => {
    setToastMessage(message)
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  // CRUD Handlers
  const handleOpenAddDrawer = () => {
    setIsAddDrawerOpen(true)
  }

  const handleCloseAddDrawer = () => {
    setIsAddDrawerOpen(false)
  }

  const handleSaveProposal = (newProposal) => {
    // Prepend newly created proposal to state and reset to page 1
    setProposals((prev) => [newProposal, ...prev])
    setCurrentPage(1)
    showToast('Proposal created successfully.')
  }

  const handleViewProposal = (proposal) => {
    setSelectedProposal(proposal)
  }

  const handleCloseDetails = () => {
    setSelectedProposal(null)
  }

  const handleEditProposal = (proposal) => {
    setSelectedProposal(null) // Seamless transition: close details drawer if open
    setEditingProposal(proposal)
  }

  const handleCloseEditDrawer = () => {
    setEditingProposal(null)
  }

  const handleUpdateProposal = (updatedProposal) => {
    // Immutable update preserving current pagination page
    setProposals((prev) =>
      prev.map((proposal) =>
        proposal.id === updatedProposal.id ? updatedProposal : proposal
      )
    )
    setEditingProposal(null)
    showToast('Proposal updated successfully.')
  }

  const handlePromptDelete = (proposal) => {
    setDeletingProposal(proposal)
  }

  const handleCloseDeleteModal = () => {
    setDeletingProposal(null)
  }

  const handleConfirmDelete = (proposalId) => {
    // Immutable deletion
    setProposals((prev) => prev.filter((p) => p.id !== proposalId))

    // Close drawers if this proposal was active
    if (selectedProposal?.id === proposalId) setSelectedProposal(null)
    if (editingProposal?.id === proposalId) setEditingProposal(null)

    setDeletingProposal(null)
    showToast('Proposal deleted successfully.')
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Add Proposal Action */}
      <ProposalsHeader onAddProposal={handleOpenAddDrawer} />

      {/* 2. Compact Dynamic Metric Summary Row (Total, Draft, Sent, Accepted) */}
      <ProposalSummary proposals={proposals} />

      {/* 3. Main Workspace Card (Toolbar + Table + Pagination) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <ProposalsToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          serviceFilter={serviceFilter}
          onServiceChange={handleServiceChange}
          serviceOptions={serviceOptions}
          totalCount={totalFilteredCount}
        />

        <ProposalsTable
          proposals={paginatedProposals}
          totalLifetimeCount={proposals.length}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={totalFilteredCount}
          itemsPerPage={PROPOSALS_PER_PAGE}
          onPageChange={handlePageChange}
          onViewProposal={handleViewProposal}
          onEditProposal={handleEditProposal}
          onDeleteProposal={handlePromptDelete}
          onAddProposal={handleOpenAddDrawer}
        />
      </div>

      {/* 4. Slide-over Add Proposal Drawer */}
      <AddProposalDrawer
        isOpen={isAddDrawerOpen}
        onClose={handleCloseAddDrawer}
        onSaveProposal={handleSaveProposal}
        existingProposals={proposals}
      />

      {/* 5. Slide-over Proposal Details Drawer */}
      <ProposalDetailsDrawer
        proposal={selectedProposal}
        isOpen={Boolean(selectedProposal)}
        onClose={handleCloseDetails}
        onEdit={handleEditProposal}
      />

      {/* 6. Slide-over Edit Proposal Drawer */}
      <EditProposalDrawer
        proposal={editingProposal}
        isOpen={Boolean(editingProposal)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdateProposal}
      />

      {/* 7. Delete Proposal Confirmation Modal */}
      <DeleteProposalModal
        proposal={deletingProposal}
        isOpen={Boolean(deletingProposal)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Proposals
