import { useState, useMemo, useEffect } from 'react'
import { CheckCircle2 } from 'lucide-react'
import PaymentsHeader from '../components/payments/PaymentsHeader'
import PaymentSummary from '../components/payments/PaymentSummary'
import PaymentsToolbar from '../components/payments/PaymentsToolbar'
import PaymentsTable from '../components/payments/PaymentsTable'
import AddPaymentDrawer from '../components/payments/AddPaymentDrawer'
import PaymentDetailsDrawer from '../components/payments/PaymentDetailsDrawer'
import EditPaymentDrawer from '../components/payments/EditPaymentDrawer'
import DeletePaymentModal from '../components/payments/DeletePaymentModal'
import { MOCK_PAYMENTS } from '../data/payments'

const PAYMENTS_PER_PAGE = 8

function Payments() {
  const [payments, setPayments] = useState(MOCK_PAYMENTS)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All Status')
  const [methodFilter, setMethodFilter] = useState('All Methods')
  const [currentPage, setCurrentPage] = useState(1)

  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false)
  const [selectedPayment, setSelectedPayment] = useState(null)
  const [editingPayment, setEditingPayment] = useState(null)
  const [deletingPayment, setDeletingPayment] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  // Real-time client-side filtering: search + status + payment method
  const filteredPayments = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()

    return payments.filter((payment) => {
      // 1. Search matches: paymentNumber, clientName, company, proposalNumber, projectName, reference
      const matchesSearch =
        !q ||
        payment.paymentNumber.toLowerCase().includes(q) ||
        payment.clientName.toLowerCase().includes(q) ||
        payment.company.toLowerCase().includes(q) ||
        (payment.proposalNumber && payment.proposalNumber.toLowerCase().includes(q)) ||
        (payment.projectName && payment.projectName.toLowerCase().includes(q)) ||
        (payment.reference && payment.reference.toLowerCase().includes(q))

      // 2. Status match
      const matchesStatus =
        statusFilter === 'All Status' || payment.status === statusFilter

      // 3. Payment Method match
      const matchesMethod =
        methodFilter === 'All Methods' || payment.paymentMethod === methodFilter

      return matchesSearch && matchesStatus && matchesMethod
    })
  }, [payments, searchQuery, statusFilter, methodFilter])

  // Pagination calculation
  const totalFilteredCount = filteredPayments.length
  const totalPages = Math.max(1, Math.ceil(totalFilteredCount / PAYMENTS_PER_PAGE))
  const activePage = Math.min(currentPage, totalPages)

  // Page clamping: if deleting or filtering items shrinks the list, move to last valid page
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  // Paginated slice for current page
  const paginatedPayments = useMemo(() => {
    const startIndex = (activePage - 1) * PAYMENTS_PER_PAGE
    return filteredPayments.slice(startIndex, startIndex + PAYMENTS_PER_PAGE)
  }, [filteredPayments, activePage])

  // Filter change handlers resetting page to 1
  const handleSearchChange = (query) => {
    setSearchQuery(query)
    setCurrentPage(1)
  }

  const handleStatusChange = (status) => {
    setStatusFilter(status)
    setCurrentPage(1)
  }

  const handleMethodChange = (method) => {
    setMethodFilter(method)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
    }
  }

  // Toast notification helper
  const showToast = (message) => {
    setToastMessage(message)
    setTimeout(() => {
      setToastMessage(null)
    }, 3500)
  }

  // CRUD Handlers
  const handleOpenAddDrawer = () => {
    setIsAddDrawerOpen(true)
  }

  const handleCloseAddDrawer = () => {
    setIsAddDrawerOpen(false)
  }

  const handleSavePayment = (newPayment) => {
    setPayments((prev) => [newPayment, ...prev])
    setCurrentPage(1)
    showToast('Payment recorded successfully.')
  }

  const handleViewPayment = (payment) => {
    setSelectedPayment(payment)
  }

  const handleCloseDetails = () => {
    setSelectedPayment(null)
  }

  const handleEditPayment = (payment) => {
    setSelectedPayment(null) // Seamless transition: close details drawer if open
    setEditingPayment(payment)
  }

  const handleCloseEditDrawer = () => {
    setEditingPayment(null)
  }

  const handleUpdatePayment = (updatedPayment) => {
    setPayments((prev) =>
      prev.map((payment) =>
        payment.id === updatedPayment.id ? updatedPayment : payment
      )
    )
    setEditingPayment(null)
    showToast('Payment updated successfully.')
  }

  const handlePromptDelete = (payment) => {
    setDeletingPayment(payment)
  }

  const handleCloseDeleteModal = () => {
    setDeletingPayment(null)
  }

  const handleConfirmDelete = (paymentId) => {
    setPayments((prev) => prev.filter((p) => p.id !== paymentId))

    if (selectedPayment?.id === paymentId) setSelectedPayment(null)
    if (editingPayment?.id === paymentId) setEditingPayment(null)

    setDeletingPayment(null)
    showToast('Payment deleted successfully.')
  }

  return (
    <div className="space-y-6 relative">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Header with Breadcrumbs, Title & Record Payment Action */}
      <PaymentsHeader onAddPayment={handleOpenAddDrawer} />

      {/* 2. Compact Dynamic Metric Summary Row (Total Received, Pending, Partial, Refunded) */}
      <PaymentSummary payments={payments} />

      {/* 3. Main Workspace Card (Toolbar + Table + Pagination) */}
      <div className="rounded-xl border border-odw-border bg-white shadow-2xs overflow-hidden">
        <PaymentsToolbar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusChange={handleStatusChange}
          methodFilter={methodFilter}
          onMethodChange={handleMethodChange}
          totalCount={totalFilteredCount}
        />

        <PaymentsTable
          payments={paginatedPayments}
          totalLifetimeCount={payments.length}
          currentPage={activePage}
          totalPages={totalPages}
          totalFilteredCount={totalFilteredCount}
          itemsPerPage={PAYMENTS_PER_PAGE}
          onPageChange={handlePageChange}
          onViewPayment={handleViewPayment}
          onEditPayment={handleEditPayment}
          onDeletePayment={handlePromptDelete}
          onAddPayment={handleOpenAddDrawer}
        />
      </div>

      {/* 4. Slide-over Add Payment Drawer */}
      <AddPaymentDrawer
        isOpen={isAddDrawerOpen}
        onClose={handleCloseAddDrawer}
        onSavePayment={handleSavePayment}
        existingPayments={payments}
      />

      {/* 5. Slide-over Payment Details Drawer */}
      <PaymentDetailsDrawer
        payment={selectedPayment}
        isOpen={Boolean(selectedPayment)}
        onClose={handleCloseDetails}
        onEdit={handleEditPayment}
      />

      {/* 6. Slide-over Edit Payment Drawer */}
      <EditPaymentDrawer
        payment={editingPayment}
        isOpen={Boolean(editingPayment)}
        onClose={handleCloseEditDrawer}
        onSave={handleUpdatePayment}
      />

      {/* 7. Delete Payment Confirmation Modal */}
      <DeletePaymentModal
        payment={deletingPayment}
        isOpen={Boolean(deletingPayment)}
        onClose={handleCloseDeleteModal}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}

export default Payments
