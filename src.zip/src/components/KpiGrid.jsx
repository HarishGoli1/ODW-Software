import KpiCard from './KpiCard'
import { DASHBOARD_KPIS } from '../data/dashboardKpis'

function KpiGrid({ kpis = DASHBOARD_KPIS }) {
  return (
    <section aria-label="Key Performance Indicators" className="space-y-3">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-odw-text-muted">
          Key Metrics
        </h2>
        <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500">
          Preview Data
        </span>
      </div>

      {/* Responsive 5-card grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {kpis.map((kpi) => (
          <KpiCard key={kpi.id} kpi={kpi} />
        ))}
      </div>
    </section>
  )
}

export default KpiGrid
