import PipelineCard from './PipelineCard'
import ProjectDeliveryCard from './ProjectDeliveryCard'
import PaymentHealthCard from './PaymentHealthCard'
import TaskHealthCard from './TaskHealthCard'
import BusinessActivityChart from './BusinessActivityChart'

function BusinessOverview() {
  return (
    <section aria-label="Business Overview" className="space-y-4">
      {/* Section Heading with subtle Preview Data Badge */}
      <div className="flex items-center justify-between pt-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-odw-text-muted">
          Business Overview
        </h2>
        <span className="rounded-md bg-slate-100 border border-slate-200/60 px-2 py-0.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wide">
          Preview Data
        </span>
      </div>

      {/* Row 1: Pipeline & Project Delivery (2 Columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PipelineCard />
        <ProjectDeliveryCard />
      </div>

      {/* Row 2: Payment Health & Task Health (2 Columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PaymentHealthCard />
        <TaskHealthCard />
      </div>

      {/* Row 3: 6-Month Business Activity Trend (Full Width) */}
      <div>
        <BusinessActivityChart />
      </div>
    </section>
  )
}

export default BusinessOverview
