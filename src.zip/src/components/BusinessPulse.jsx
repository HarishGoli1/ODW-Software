import UpcomingWork from './UpcomingWork'
import RecentActivity from './RecentActivity'

function BusinessPulse() {
  return (
    <section aria-label="Business Pulse" className="space-y-4">
      {/* Section Header */}
      <div className="flex items-center justify-between pt-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-odw-text-muted">
          Business Pulse
        </h2>
        <span className="rounded-md bg-slate-100 border border-slate-200/60 px-2 py-0.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wide">
          Preview Data
        </span>
      </div>

      {/* Two-Column Responsive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <UpcomingWork />
        <RecentActivity />
      </div>
    </section>
  )
}

export default BusinessPulse
