import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import AppLayout from './layouts/AppLayout'
import Dashboard from './pages/Dashboard'
import Leads from './pages/Leads'
import Clients from './pages/Clients'
import Projects from './pages/Projects'
import Tasks from './pages/Tasks'
import ProjectTasks from './pages/ProjectTasks'
import Calendar from './pages/Calendar'
import Proposals from './pages/Proposals'
import Payments from './pages/Payments'
import Team from './pages/Team'
import ModulePlaceholder from './pages/ModulePlaceholder'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/leads" element={<Leads />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/tasks/project/:projectId" element={<ProjectTasks />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/proposals" element={<Proposals />} />
          <Route path="/payments" element={<Payments />} />
          <Route path="/team" element={<Team />} />
        </Route>
        <Route path="*" element={<div>Page Not Found</div>} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
